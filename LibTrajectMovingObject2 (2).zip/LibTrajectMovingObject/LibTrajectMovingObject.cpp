
#include "stdafx.h"
#include "STR-TREE.h"
#include <iostream>
#include <time.h>
#include<conio.h>
#include"TB-tree.h"

#include "R_tree_leaf.h"
#include "R_tree_time.h"

#include "SETI.h"
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{

	//RTreeTime a(3);
	//int ID=1;
	//int x1=1;
	//int x2=2;
	//int y1=1;
	//int y2=2;
	//int t1=1;
	//int t2=2;
	//for(int p=0; p<10; p++)
	//{
	//	/*LeafOfTraject *b=new LeafOfTraject;
	//	b->ID_Leaf=ID;
	//	for(int i=0; i<3; i++)
	//	{
	//		Traject *Tr1=new Traject(x1,y1,x2,y2,1,5,t1,t2);
	//		x1=x2;
	//		x2++;
	//		y1=y2;
	//		y2++;
	//		t1=t2;
	//		t2++;
	//		b->InsertTrajectory(Tr1);
	//	}
	//	a.InsertLeaf(b);*/
	//	a.InsertID(t1,ID);
	//	t1++;
	//	ID++;
	//}
	//TimeRange c;
	//c.T0=3;
	//c.T1=7;
	//ListOfID* IDsList = a.FindIDs(a.GetRoot(),&c);

	//RTreeLeaf F(3);
	//int ID2=1;
	//int x11=1;
	//int x22=2;
	//int y11=1;
	//int y22=2;
	//int t11=1;
	//int t22=2;
	//for(int p=0; p<10; p++)
	//{
	//	LeafOfTraject *b=new LeafOfTraject;
	//	b->ID_Leaf=ID2;
	//	for(int i=0; i<3; i++)
	//	{
	//		Traject *Tr1=new Traject(x11,y11,x22,y22,1,5,t11,t22);
	//		x11=x22;
	//		x2++;
	//		y11=y22;
	//		y22++;
	//		t11=t22;
	//		t22++;
	//		b->InsertTrajectory(Tr1);
	//	}
	//	F.InsertLeaf(b);
	//	t1++;
	//	ID2++;
	//}
	//ListOfLeafs * Temp = F.FindLeafs(F.GetRoot(),IDsList);

	SETI *a=new SETI(2,40,40,20);
	a->InsertDot(0,0,0,0);
	a->InsertDot(0,10,0,1);
	int x2=1;
	int y2=9;
	int t2=1;
	int x=1;
	int y=1;
	int t=1;
	for(int i=0; i<10; i++)
	{
		a->InsertDot(x,y,t,0);
		x++;
		y++;
		t++;
		a->InsertDot(x2,y2,t,1);
		x2++;
		y2--;
	}

	int col=0;
	TrajectObj* Arr=a->FindTrajectory(&MBR(6,0,0,6,0,6),1,col);	
	for(int i=0; i<col; i++)
		cout<<Arr[i].X<<" "<<Arr[i].Y<<endl;
	getch();
	return 0;
}

